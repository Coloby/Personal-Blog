- Scared about forgetting fleeting thoughts? write everything here
- This note is needed as an inbox. 
	- Sometimes your thoughts are important but you can't process them on the spot.
	- Put anything that's new, important, but not urgent to think about. 
	- Maybe you are working on a project and you have an interesting idea. Don't lose focus, just put stuff in there for a better time.
	- categorize stuff through lists so that you don't lose important ideas when they stack
- I also use this note for daily things or tasks

### Examples
- Project 1
	- Today
		- [ ] Basic design
			- [ ] Hero
			- [ ] Header
			- [ ] Footer
	- Inspiration
		- Contact section
			- [ ] Make a rocket land every time someone clicks on a link
- Studying for an exam
	- [ ] Biology
	- [ ] Chemistry
	- [ ] Magic Spells

#### Worktable
Here you might have important thoughts that you can't process at the moment

- Anything bad probably happens because we're dying
	- The opposite of growth is dying