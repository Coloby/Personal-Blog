- That's an example of what your Hub/Home/Main/Entrance note can be. 
	- The purpose is to create big categories of topics you like, so that you can't forget notes or have too many orphans (notes that are not connected to any other notes).

- Fav topics
	[[Languages]]
	[[Animals]]
	[[Gym]]
	[[Books]]
- Studies
	[[Studies of the Earth]]
	[[psychology]]
	[[minerals]]
- Other
	[[Just a test note]]
	- Strange ones
		- [[Flying elephants]]
		- [[Burrito mania]]
		- [[4 forks, 1 plate]]