- What? a language that doesn't exist!
- why? just to let you understand a little better how you can use connections instead of folders to organize your notes

- Basics
	- Hello = Karatubetele
	- Hi = OogaBooga