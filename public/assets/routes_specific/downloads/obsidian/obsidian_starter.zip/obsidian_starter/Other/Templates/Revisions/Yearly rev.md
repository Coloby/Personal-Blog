---
Date: <% tp.date.now("YYYY-MM-DD") %>
💫Highlight: 
Title: 
Vote: 
🧔: 
💸: 
👯‍♀️: 
⛑: 
MIT: 0
Type: Yearly
--- 
## Progress

- [ ] **MIT**: 
- [ ] 

- plan to achieve
	1. 
		- 
	2. 
		- 

## Standard to-dos
- [ ] Check and Update if needed
	- [ ] [[Introspection]]
	- [ ] [[To-do relationships]]
	- [ ] [[Stuff I need]]
	- [ ] [[CC]] high views
	- [ ] Are you really using [[Productivity]]
	- [ ] what can I optimize/automate?
	- [ ] Find patterns w 
		- [ ] [[Schedule making]]
		- [ ] past habits table & data
- [ ] schedule
	- [ ] Introspection problems or need to explore? validate long term vision
- [ ] *ACTUALLY FILLED METADATA AND JOURNALED?*
	- all of this it's useless if you don't put meaningful data in these notes.
	- go check WHY you journal
	- [ ] you need this to kill the fact that you can't remember your past
## **WWH and ~ (y,n,good,bad)** based on when
- 
	### Past - Was this better than the last one?
	- 
	
	- More
		- checks
			- [ ] Had I any meaningful highlights?
				- 
			- [ ] Was I open minded?
				- 
		- todos
			- [ ] are there any new bad habits and problems? Anti productivity [fonte](https://www.youtube.com/watch?v=_YyzFYWjuuI)
				- 
				- theory
					- suppression - not working on damaging problems because of fear
					- *escapism* - procastinating
						- why? - from what discomfort/emotion are you escaping?
					- projection - 
	
	### Present - Feelings about this period?
	- 
	
	- More
		- 
	
	### Future - expectations, reality, changes needed?
	- 
	
	- More
		- Come sarebbe la tua vita tra 5 anni continuando così?
		- Principles application check - think above sudgestions
			- [ ] [[MIT - Most Important Task]] - what should MIT be?
				- 
				- [ ] Have I balanced quantity * quality = outputs?
				- [ ] bottlenecks to solve?
				- [ ] useless stuff I'm doing vs important stuff I should do?
					- Dovresti aggiungere o eliminare quello che fai ...
						- [ ] se comparato al tuo purpose?
						- [ ] bcs unrelated to your purpose?
						- [ ] bcs is not enough?
						- [ ] Are the people you talk to worth it? [[HT evaluate friendships]]
						-
						- 
				- [ ] am I 
					- [ ] resting properly with great rewards? 
					- [ ] a fly?
					- [ ] posticipating as I should?

			- [ ] Is my [[Predicting]] fast & precise compared to problems?
				- 
			- [ ] Did I solve problems w [[Pragmatism]]?
				- 
			- [ ] Have I been resilient even after failures?
				- 
		
	### What you fear? What you dream?
	- 
	
	- ?
		- 

### Conclusions


