---
Date: <% tp.date.now("YYYY-MM-DD") %>
💫Highlight: 
Title: 
vote: 
MIT: 0
Type: Daily
---
[[<% moment().subtract(1, 'day').format("DD-MM-YYYY") %> W<% moment().subtract(1, 'day').isoWeek().toString().padStart(2, '0') %> ]]  [[<% moment().add(1, 'day').format("DD-MM-YYYY") %> W<% moment().add(1, 'day').isoWeek().toString().padStart(2, '0') %> ]] 

### 2 to-dos
- [ ] **MIT:** 
- [ ] 

- Standard
	- Execute
		- [ ] 4h
	- Learn
		- [ ] 2h
	- Share/Help
		- [ ] 2h
	- Think
		- [ ] Night ritual

### 5 things I'm greatful for
1. 
2. 
3. 
4. 
5. 

### reflections
