---
Date: <% moment().startOf('month').format("YYYY-MM-DD") %>
💫Highlight: 
Title: 
Vote: 
🧔: 
💸: 
👯‍♀️: 
⛑: 
MIT: 0
Type: Montly
---
### old 3 to-dos
	![[<% tp.date.now("MM-YYYY", "P-1M") %>###3 to-dos]]

- [ ] **MIT:**
- [ ] 
- [ ] 

- Plan to achieve
	1. 
		- 
	2. 
		- 

### 5 things I'm greatful for
1. 
2. 
3. 
4. 
5. 

### Standard to-dos
- [ ] Update if needed
	- [ ] [[Introspection]]
	- [ ] [[To-do relationships]]
- [ ] Integrate yearly tasks?
- [ ] Guardare il calendario per eventi possibilmente importanti
- [ ] search one time only stuff from [[Atomic habits]] pag 196

### Was this better than the last one?

- todos
	- [ ] are there any new bad habits? 

### Where are you now?


### Where you’re going or want to go?


### Should you change to obtain it?

- todos
	- [ ] +/- quello che fai se comparato al tuo purpose? 
	- [ ] Is what you're doing related to your purpose? 
	- [ ] Pensi che quello che fai sia abbastanza? 

### What you fear? What you dream?


### Recap
