what is this? Read the title. This note won't show up in the graph because it's in the folder: `Other/no-graph`

To easily ***m**ove* notes around you can use `ctrl + m`, and then select where to put the current note