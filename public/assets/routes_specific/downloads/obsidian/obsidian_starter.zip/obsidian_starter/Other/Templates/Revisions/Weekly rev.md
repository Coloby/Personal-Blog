---
Date: <% moment().startOf('isoWeek').format("YYYY-MM-DD") %>
💫Highlight: 
Title: 
Vote: 
🧔: 
💸: 
👯‍♀️: 
⛑: 
MIT: 0
Type: Weekly
---
## Progress -  [[W<% moment().subtract(1, 'week').isoWeek() %> of <% moment().isoWeeksInYear(moment().year()) %>-<% moment().year() %>]]

- [ ] **MIT:** 

- [ ] Standard
	- [ ] 1 big-idea / Article

- Plan to achieve
	1. 
		- 
	2. 
		- 

### This week time table

| Mon | Tue | Wen | Thu | Fri | Sat | Sun |
| --- | --- | --- | --- | --- | --- | --- |
| 5 | 5 | 5 | 5 | 4 | 4 | 4 |
32h scheduled

| Mon | Tue | Wen | Thu | Fri | Sat | Sun |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | 0 | 0 | 0 | 0 | 0 | 0 |
h actually done

## Standard to-dos
- [ ] Check and Update if needed
	- [ ] [[Introspection]]
	- [ ] [[To-do relationships]]
	- [ ] [[Stuff I need]]
	- [ ] [[CC]] high views
	- [ ] Are you really using [[Productivity]]
	- [ ] what can I optimize/automate?
	- [ ] Find patterns w
		- [ ] [[Schedule making]]
		- [ ] past habits table & data
	- [ ] [[My backstory]]
- [ ] schedule
	- [ ] Introspection problems or need to explore? validate long term vision
	- [ ] Integrate montly tasks?
	- [ ] watch yearly
- [ ] *ACTUALLY FILLED METADATA AND JOURNALED?*
	- all of this it's useless if you don't put meaningful data in these notes.
	- go check WHY you journal
	- [ ] you need this to kill the fact that you can't remember your past

## **WWH and ~  (y,n,good,bad)**** based on when
- 
	### Past - Was this better than the last one?
	- 
	
	- 
		- [ ] u entrepeneur? [[BU vocabs]] 
		- [ ] are there any new bad habits and problems? Anti productivity [fonte](https://www.youtube.com/watch?v=_YyzFYWjuuI)
			- suppression - not working on damaging problems because of fear
			- *escapism* - procastinating
				- why? - from what discomfort/emotion are you escaping?
			- projection - 
	
	### Present - Feelings about this period?
	- 
	
	- Is the work too boring or lacking quality/effectiveness?
	
	### Future - expectations, reality, changes needed?
	- 
	
	- Principles - apply & check - think above suggestions
		- [ ] [[MIT - Most Important Task]] - what should MIT be?
			- [ ] bottlenecks to solve?
			- [ ] useless stuff I'm doing vs important stuff I should do?
				- Should you add or delete what you do ...
					- [ ] compared to purpose?
					- [ ] bcs unrelated to your purpose?
					- [ ] bcs is not enough?
				- [ ] Are the people you talk to worth it? [[HT evaluate friendships]]
			- [ ] am I 
				- [ ] resting properly with great rewards? 
				- [ ] a fly?
				- [ ] posticipating as I should?
	
	### What you fear? What you dream?
	- 
	
	- ?
		- 

